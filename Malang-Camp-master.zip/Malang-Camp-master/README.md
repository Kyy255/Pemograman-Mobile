# Malang-Camp

E-mail for Pegawai: admin@gmail.com

Password for Pegawai: admin12345
