package com.firmansyah.malangcamp.theme

import androidx.compose.ui.graphics.Color


val blue = Color(0xff1E90FF)
val blueDark = Color(0xff0063cb)
val teal200 = Color(0xFF03DAC5)
val teal700 = Color(0xFF018786)
val black = Color(0xFF000000)
val white = Color(0xFFFFFFFF)
val darkGreen = Color(0xff2E5F36)
val green = Color(0xff26DE81)
